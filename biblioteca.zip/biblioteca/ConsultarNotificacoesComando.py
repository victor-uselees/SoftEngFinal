from Comando import Comando
from Repositorio import Repositorio
from Professor import Professor

class ConsultarNotificacoesComando(Comando):
    def __init__(self, codigo_usuario):
        self.codigo_usuario = codigo_usuario

    def executar(self):
        repositorio = Repositorio()
        usuario = repositorio.encontrar_usuario(self.codigo_usuario)
        if usuario and isinstance(usuario, Professor):
            print(f"Professor {usuario.nome} foi notificado {usuario.contador_notificacoes} vezes.")
        else:
            print("Usuário não é um professor ou não foi encontrado.")