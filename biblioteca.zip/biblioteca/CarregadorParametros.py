from AlunoGraduacao import AlunoGraduacao
from AlunoPosGraduacao import AlunoPosGraduacao
from Professor import Professor
from Livro import Livro
from Exemplar import Exemplar
from Repositorio import Repositorio

def carregar_usuarios(repositorio):
    usuarios = [
        AlunoGraduacao(123, "João da Silva"),
        AlunoPosGraduacao(456, "Luiz Fernando Rodrigues"),
        AlunoGraduacao(789, "Pedro Paulo"),
        Professor(100, "Carlos Lucena")
    ]
    for usuario in usuarios:
        repositorio.adicionar_usuario(usuario)

def carregar_livros(repositorio):
    livros = [
        Livro(100, "Engenharia de Software", "Addison Wesley", "Ian Sommervile", "6ª", 2000),
        Livro(101, "UML - Guia do Usuário", "Campus", "Grady Booch, James Rumbaugh, Ivar Jacobson", "7ª", 2000),
        Livro(200, "Code Complete", "Microsoft Press", "Steve McConnell", "2ª", 2014),
        Livro(201, "Agile Software Development, Principles, Patterns and Practices", "Prentice Hall", "Robert Martin", "1ª", 2002),
        Livro(300, "Refactoring: Improving the Design of Existing Code", "Addison Wesley Professional", "Martin Fowler", "1ª", 1999),
        Livro(301, "Software Metrics: A rigorous and Practical Approach", "CRC Press", "Norman Fenton, James Bieman", "3ª", 2014),
        Livro(400, "Design Patterns: Element of Reusable Object-Oriented Software", "Addison Wesley Professional", "Erich Gamma, Richard Helm, Ralph Johnson, John Vlissides", "1ª", 1994),
        Livro(401, "UML Distilled: A Brief Guide to the Standard Object Modeling Language", "Addison Wesley Professional", "Martin Fowler", "3ª", 2003)
    ]
    for livro in livros:
        repositorio.adicionar_livro(livro)

def carregar_exemplares(repositorio):
    exemplares = [
        (100, "01"), (100, "02"),
        (101, "03"),
        (200, "04"),
        (201, "05"),
        (300, "06"), (300, "07"),
        (400, "08"), (400, "09")
    ]
    for codigo_livro, codigo_exemplar in exemplares:
        livro = repositorio.encontrar_livro(codigo_livro)
        if livro:
            livro.adicionar_exemplar(Exemplar(codigo_livro, codigo_exemplar))

def carregar_dados():
    repositorio = Repositorio()
    carregar_usuarios(repositorio)
    carregar_livros(repositorio)
    carregar_exemplares(repositorio)
    return repositorio