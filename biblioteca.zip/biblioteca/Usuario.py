from abc import ABC, abstractmethod

class Usuario(ABC):
    def __init__(self, codigo, nome, regra_emprestimo):
        self._codigo = codigo
        self._nome = nome
        self._emprestimos = []
        self._reservas = []
        self._regra_emprestimo = regra_emprestimo

    @property
    def codigo(self):
        return self._codigo

    @property
    def nome(self):
        return self._nome

    @nome.setter
    def nome(self, value):
        self._nome = value

    @property
    def emprestimos(self):
        return self._emprestimos

    @property
    def reservas(self):
        return self._reservas

    @property
    def regra_emprestimo(self):
        return self._regra_emprestimo

    @regra_emprestimo.setter
    def regra_emprestimo(self, value):
        self._regra_emprestimo = value

    def pode_emprestar(self, livro, repositorio):
        return self.regra_emprestimo.pode_emprestar(self, livro, repositorio)

    def adicionar_emprestimo(self, emprestimo):
        self._emprestimos.append(emprestimo)

    @abstractmethod
    def tempo_emprestimo(self):
        pass