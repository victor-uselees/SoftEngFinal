from CarregadorParametros import carregar_dados
from ComandoFactory import ComandoFactory  


def main():
    repositorio = carregar_dados()
    print("Sistema de Biblioteca Iniciado. Digite 'sai' para sair.")

    while True:
        entrada = input("Digite o comando: ").strip().split()
        if not entrada:
            continue

        nome_comando = entrada[0]
        parametros = list(map(int, entrada[1:]))

        if nome_comando == "sai":
            print("Saindo do sistema...")
            break

        try:
            comando = ComandoFactory.criar_comando(nome_comando, *parametros)
            comando.executar()
        except ValueError as e:
            print(f"Erro: {e}")
        except Exception as e:
            print(f"Erro inesperado: {e}")


if __name__ == "__main__":
    main()
