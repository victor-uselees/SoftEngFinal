from RegraEmprestimoProfessor import RegraEmprestimoProfessor
from Usuario import Usuario

class Professor(Usuario):
    def __init__(self, codigo, nome):
        super().__init__(codigo, nome, RegraEmprestimoProfessor())
        self._contador_notificacoes = 0

    @property
    def contador_notificacoes(self):
        return self._contador_notificacoes

    @contador_notificacoes.setter
    def contador_notificacoes(self, value):
        self._contador_notificacoes = value

    def tempo_emprestimo(self):
        return 8

    def notificar(self):
        self.contador_notificacoes += 1