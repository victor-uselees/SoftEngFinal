from datetime import datetime, timedelta
class Reserva:
    def __init__(self, usuario, livro):
        self.usuario = usuario
        self.livro = livro
        self.data_reserva = datetime.now()