from Comando import Comando
from Repositorio import Repositorio
from Reserva import Reserva

class ReservarComando(Comando):
    def __init__(self, codigo_usuario, codigo_livro):
        self.codigo_usuario = codigo_usuario
        self.codigo_livro = codigo_livro

    def executar(self):
        repositorio = Repositorio()
        usuario = repositorio.encontrar_usuario(self.codigo_usuario)
        livro = repositorio.encontrar_livro(self.codigo_livro)

        if usuario and livro:
            if len([r for r in repositorio.reservas if r.usuario.codigo == usuario.codigo]) < 3:
                reserva = Reserva(usuario, livro)
                repositorio.registrar_reserva(reserva)
                print(f"Reserva realizada com sucesso para {usuario.nome}.")
                if len([r for r in repositorio.reservas if r.livro.codigo == livro.codigo]) > 2:
                    repositorio.notificar_observadores(livro.codigo)
            else:
                print("Reserva não permitida. Limite de reservas atingido.")
        else:
            print("Reserva não realizada. Verifique os dados informados.")