class RegraEmprestimoPadrao:
    def __init__(self, limite_emprestimos):
        self.limite_emprestimos = limite_emprestimos

    def pode_emprestar(self, usuario, livro, repositorio):
        if len(usuario.emprestimos) >= self.limite_emprestimos:
            return False, "Limite de empréstimos atingido."

        if any(emp.exemplar.codigo_livro == livro.codigo for emp in usuario.emprestimos):
            return False, "Usuário já possui um empréstimo deste livro."

        reservas = [r for r in repositorio.reservas if r.livro.codigo == livro.codigo]
        exemplares_disponiveis = len([ex for ex in livro.exemplares if ex.status == "Disponível"])
        
        if len(reservas) >= exemplares_disponiveis and not any(r.usuario.codigo == usuario.codigo for r in reservas):
            return False, "Todos os exemplares estão reservados."

        return True, ""
