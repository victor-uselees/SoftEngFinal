from Comando import Comando
from Repositorio import Repositorio

class ObservadorComando(Comando):
    def __init__(self, codigo_usuario, codigo_livro):
        self.codigo_usuario = codigo_usuario
        self.codigo_livro = codigo_livro

    def executar(self):
        repositorio = Repositorio()
        usuario = repositorio.encontrar_usuario(self.codigo_usuario)
        livro = repositorio.encontrar_livro(self.codigo_livro)

        if usuario and livro:
            if self.codigo_livro not in repositorio.observadores:
                repositorio.observadores[self.codigo_livro] = []
            repositorio.observadores[self.codigo_livro].append(usuario)
            print(f"Professor {usuario.nome} registrado como observador do livro {livro.titulo}.")
        else:
            print("Registro de observador não realizado. Verifique os dados informados.")