from RegraEmprestimoPadrao import RegraEmprestimoPadrao

class RegraEmprestimoAlunoPosGraduacao(RegraEmprestimoPadrao):
    def __init__(self):
        super().__init__(limite_emprestimos=3)
