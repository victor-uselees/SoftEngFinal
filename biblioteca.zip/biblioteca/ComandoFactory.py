from EmprestarComando import EmprestarComando
from DevolverComando import DevolverComando
from ReservarComando import ReservarComando
from ConsultarLivroComando import ConsultarLivroComando
from ConsultarUsuario import ConsultarUsuario
from ConsultarNotificacoesComando import ConsultarNotificacoesComando
from ObservadorComando import ObservadorComando

class ComandoFactory:
    _comandos = {
        "emp": EmprestarComando,
        "dev": DevolverComando,
        "res": ReservarComando,
        "liv": ConsultarLivroComando,
        "usu": ConsultarUsuario,
        "uf": ConsultarNotificacoesComando,
        "obs": ObservadorComando
    }

    @staticmethod
    def criar_comando(nome, *args):
        if nome in ComandoFactory._comandos:
            return ComandoFactory._comandos[nome](*args)
        else:
            raise ValueError("Comando inválido")
