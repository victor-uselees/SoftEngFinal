from RegraEmprestimoAlunoGraduacao import RegraEmprestimoAlunoGraduacao
from Usuario import Usuario

class AlunoGraduacao(Usuario):
    def __init__(self, codigo, nome):
        super().__init__(codigo, nome, RegraEmprestimoAlunoGraduacao())

    def tempo_emprestimo(self):
        return 4