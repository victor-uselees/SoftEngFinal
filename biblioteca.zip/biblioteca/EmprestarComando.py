from Comando import Comando
from Repositorio import Repositorio
from datetime import datetime

class EmprestarComando(Comando):
    def __init__(self, codigo_usuario, codigo_livro):
        self.codigo_usuario = codigo_usuario
        self.codigo_livro = codigo_livro

    def executar(self):
        repositorio = Repositorio()
        usuario = repositorio.encontrar_usuario(self.codigo_usuario)
        livro = repositorio.encontrar_livro(self.codigo_livro)
        exemplar = repositorio.encontrar_exemplar_disponivel(self.codigo_livro)

        if usuario and livro and exemplar:
            pode_emprestar, mensagem = usuario.pode_emprestar(livro, repositorio)
            if pode_emprestar:
                exemplar.status = "Emprestado"
                exemplar.data_emprestimo = datetime.now()
                exemplar.usuario_emprestimo = usuario
                repositorio.registrar_emprestimo(usuario, exemplar)
                print(f"Empréstimo realizado com sucesso para {usuario.nome}.")
            else:
                print(f"Empréstimo não permitido para {usuario.nome}. Motivo: {mensagem}")
        else:
            print("Empréstimo não realizado. Verifique os dados informados.")