class Livro:
    def __init__(self, codigo, titulo, editora, autores, edicao, ano_publicacao):
        self._codigo = codigo
        self._titulo = titulo
        self._editora = editora
        self._autores = autores
        self._edicao = edicao
        self._ano_publicacao = ano_publicacao
        self._exemplares = []

    @property
    def codigo(self):
        return self._codigo

    @property
    def titulo(self):
        return self._titulo

    @titulo.setter
    def titulo(self, value):
        self._titulo = value

    @property
    def editora(self):
        return self._editora

    @editora.setter
    def editora(self, value):
        self._editora = value

    @property
    def autores(self):
        return self._autores

    @autores.setter
    def autores(self, value):
        self._autores = value

    @property
    def edicao(self):
        return self._edicao

    @edicao.setter
    def edicao(self, value):
        self._edicao = value

    @property
    def ano_publicacao(self):
        return self._ano_publicacao

    @ano_publicacao.setter
    def ano_publicacao(self, value):
        self._ano_publicacao = value

    @property
    def exemplares(self):
        return self._exemplares

    def adicionar_exemplar(self, exemplar):
        self._exemplares.append(exemplar)