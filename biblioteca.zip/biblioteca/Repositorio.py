from Emprestimo import Emprestimo
from Reserva import Reserva
class Repositorio:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Repositorio, cls).__new__(cls)
            cls._instance._usuarios = []
            cls._instance._livros = []
            cls._instance._emprestimos = []
            cls._instance._reservas = []
            cls._instance._observadores = {}
        return cls._instance

    def adicionar_usuario(self, usuario):
        self._usuarios.append(usuario)

    def adicionar_livro(self, livro):
        self._livros.append(livro)

    def encontrar_livro(self, codigo_livro):
        for livro in self._livros:
            if livro.codigo == codigo_livro:
                return livro
        return None

    def encontrar_usuario(self, codigo_usuario):
        for usuario in self._usuarios:
            if usuario.codigo == codigo_usuario:
                return usuario
        return None

    def encontrar_exemplar_disponivel(self, codigo_livro):
        livro = self.encontrar_livro(codigo_livro)
        if livro:
            for exemplar in livro.exemplares:
                if exemplar.status == "Disponível":
                    return exemplar
        return None

    def registrar_emprestimo(self, usuario, exemplar):
        emprestimo = Emprestimo(usuario, exemplar)
        self._emprestimos.append(emprestimo)
        usuario.adicionar_emprestimo(emprestimo)

    def registrar_reserva(self, reserva):
        self._reservas.append(reserva)

    def notificar_observadores(self, codigo_livro):
        if codigo_livro in self._observadores:
            for observador in self._observadores[codigo_livro]:
                observador.notificar()

    @property
    def usuarios(self):
        return self._usuarios

    @property
    def livros(self):
        return self._livros

    @property
    def emprestimos(self):
        return self._emprestimos

    @property
    def reservas(self):
        return self._reservas

    @property
    def observadores(self):
        return self._observadores