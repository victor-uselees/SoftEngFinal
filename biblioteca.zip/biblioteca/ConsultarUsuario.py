from Comando import Comando
from Repositorio import Repositorio

class ConsultarUsuario(Comando):
    def __init__(self, codigo_usuario):
        self.codigo_usuario = codigo_usuario

    def executar(self):
        repositorio = Repositorio()
        usuario = repositorio.encontrar_usuario(self.codigo_usuario)
        if usuario:
            print(f"Usuário: {usuario.nome}")
            print("Empréstimos atuais:")
            for emprestimo in repositorio.emprestimos:
                if emprestimo.usuario.codigo == usuario.codigo and emprestimo.exemplar.status == "Emprestado":
                    print(f"Livro: {emprestimo.exemplar.codigo_livro}, Data de empréstimo: {emprestimo.data_emprestimo}, Data de devolução prevista: {emprestimo.data_devolucao}")
            print("Reservas:")
            for reserva in repositorio.reservas:
                if reserva.usuario.codigo == usuario.codigo:
                    print(f"Livro: {reserva.livro.titulo}, Data da reserva: {reserva.data_reserva}")
        else:
            print("Usuário não encontrado.")