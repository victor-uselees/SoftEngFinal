class Exemplar:
    def __init__(self, codigo_livro, codigo_exemplar):
        self.codigo_livro = codigo_livro
        self.codigo_exemplar = codigo_exemplar
        self.status = "Disponível"
        self.data_emprestimo = None
        self.data_devolucao = None
        self.usuario_emprestimo = None