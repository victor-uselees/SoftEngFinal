from Comando import Comando
from Repositorio import Repositorio

class ConsultarLivroComando(Comando):
    def __init__(self, codigo_livro):
        self.codigo_livro = codigo_livro

    def executar(self):
        repositorio = Repositorio()
        livro = repositorio.encontrar_livro(self.codigo_livro)
        if livro:
            print(f"Título: {livro.titulo}")
            print(f"Quantidade de reservas: {len([r for r in repositorio.reservas if r.livro.codigo == self.codigo_livro])}")
            for reserva in repositorio.reservas:
                if reserva.livro.codigo == self.codigo_livro:
                    print(f"Reserva feita por: {reserva.usuario.nome} em {reserva.data_reserva}")
            for exemplar in livro.exemplares:
                status = "Disponível" if exemplar.status == "Disponível" else f"Emprestado para {exemplar.usuario_emprestimo.nome}"
                print(f"Exemplar {exemplar.codigo_exemplar}: {status}")
        else:
            print("Livro não encontrado.")