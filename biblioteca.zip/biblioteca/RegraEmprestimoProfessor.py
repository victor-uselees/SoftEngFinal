from RegraEmprestimoPadrao import RegraEmprestimoPadrao

class RegraEmprestimoProfessor(RegraEmprestimoPadrao):
    def __init__(self):
        super().__init__(limite_emprestimos=1000)

    def pode_emprestar(self, usuario, livro, repositorio):
        return True, "" 
