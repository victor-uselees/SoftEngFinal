from Comando import Comando
from Repositorio import Repositorio

class DevolverComando(Comando):
    def __init__(self, codigo_usuario, codigo_livro):
        self.codigo_usuario = codigo_usuario
        self.codigo_livro = codigo_livro

    def executar(self):
        repositorio = Repositorio()
        usuario = repositorio.encontrar_usuario(self.codigo_usuario)
        livro = repositorio.encontrar_livro(self.codigo_livro)

        if usuario and livro:
            for emprestimo in repositorio.emprestimos:
                if emprestimo.usuario.codigo == usuario.codigo and emprestimo.exemplar.codigo_livro == livro.codigo:
                  
                    emprestimo.exemplar.status = "Disponível"
                    emprestimo.exemplar.data_emprestimo = None
                    emprestimo.exemplar.usuario_emprestimo = None

                    usuario.emprestimos.remove(emprestimo)
                    repositorio.emprestimos.remove(emprestimo)

                    print(f"Devolução realizada com sucesso por {usuario.nome}.")
                    return
            print("Devolução não realizada. Verifique os dados informados.")
        else:
            print("Devolução não realizada. Verifique os dados informados.")